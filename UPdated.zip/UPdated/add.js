function populateYears(startYear) {
    const yearSelect = document.getElementById("year");
    const currentYear = new Date().getFullYear();
    
    for (let year = startYear; year <= currentYear; year++) {
        const option = document.createElement("option");
        option.value = year;
        option.textContent = year;
        yearSelect.appendChild(option);
    }
}

window.onload = function() {
    populateYears(1900); 
};